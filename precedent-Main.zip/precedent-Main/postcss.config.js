module.exports = {
plugins: {
tailwindcss: {},
autoprefixer: {},
cssnano: {}, // Minifies your CSS for production
'postcss-preset-env': {
stage: 1,
features: {
'nesting-rules': true,
},
},
},
};
