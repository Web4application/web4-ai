// pages/_app.js
import * as React from 'react';
import { CssBaseline, ThemeProvider } from '@mui/material';
import theme from '../src/theme';

export default function MyApp(props) {
const { Component, pageProps } = props;

React.useEffect(() => {
// Remove the server-side injected CSS.
const jssStyles = document.querySelector('#jss-server-side');
if (jssStyles) {
jssStyles.parentElement.removeChild(jssStyles);
}
}, []);

return (
<ThemeProvider theme={theme}>
<CssBaseline />
<Component {...pageProps} />
</ThemeProvider>
);
}
