module.exports = {
testEnvironment: "jsdom",
setupFilesAfterEnv: ["<rootDir>/jest.setup.js"],
moduleNameMapper: {
"^@/(.*)$": "<rootDir>/src/$1",
},
testPathIgnorePatterns: ["/node_modules/", "/.next/"],
collectCoverage: true, // Collect test coverage
coverageDirectory: "coverage", // Output directory for coverage reports
coverageReporters: ["json", "lcov", "text", "clover"], // Coverage report formats
};
