module.exports = {
semi: true,
singleQuote: true,
trailingComma: "all",
tabWidth: 2,
printWidth: 80, // Set maximum line length
bracketSpacing: true, // Add spaces between brackets
jsxBracketSameLine: false, // Put the `>` of a multi-line JSX element at the end of the last line
};
