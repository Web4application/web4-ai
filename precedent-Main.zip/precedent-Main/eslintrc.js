Module.exports = {
extends: ["next", "next/core-web-vitals", "plugin:prettier/recommended"],
plugins: ["prettier", "react-hooks"],
rules: {
semi: ["error", "always"],
quotes: ["error", "single"],
"prettier/prettier": "error",
"react-hooks/rules-of-hooks": "error",
"react-hooks/exhaustive-deps": "warn"
}
};
